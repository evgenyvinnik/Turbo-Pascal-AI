{
    Copyright (c) 2001-2010, 2013 by Peter Vreman and Jonas Maebe

    Includes the LLVM-dependent target units

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

 ****************************************************************************
}
unit llvmtarg;

{$i fpcdefs.inc}

interface


implementation

    uses
      systems { prevent a syntax error when nothing is included }

{$ifndef NOOPT}
//      ,aoptcpu
{$endif NOOPT}

{**************************************
             Targets
**************************************}

{**************************************
             Assemblers
**************************************}

      ,agllvm

{**************************************
        Assembler Readers
**************************************}

{**************************************
             Debuginfo
**************************************}

      ;

end.
