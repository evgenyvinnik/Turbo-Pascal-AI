{
    This file is part of the Free Pascal run time library.
    Copyright (c) 2005 by Michael Van Canneyt, Peter Vreman,
    & Daniel Mantione, members of the Free Pascal development team.

    See the file COPYING.FPC, included in this distribution,
    for details about the copyright.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 **********************************************************************}

unit si_dll;

{$ifdef CPUSPARC64}
  { Force PIC code for sparc64 cpu }
  {$PIC ON}
{$endif CPUSPARC64}

interface

{$i si_intf.inc}

implementation

{$i sysnr.inc}
{$i si_impl.inc}
{$i si_dll.inc}

end.
